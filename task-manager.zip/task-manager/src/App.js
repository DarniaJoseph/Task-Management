import React, { useState } from "react";
import TaskList from "./components/TaskList";
import AddTask from "./components/AddTask";
import DarkModeToggle from "./components/DarkModeToggle";
import "bootstrap/dist/css/bootstrap.min.css";

const App = () => {
  const [tasks, setTasks] = useState([]);

  return (
    <div className="container mt-4">
      <h1 className="text-center">Task Manager</h1>
      <DarkModeToggle />
      <AddTask setTasks={setTasks} />
      <TaskList tasks={tasks} setTasks={setTasks} />
    </div>
  );
};

export default App;
