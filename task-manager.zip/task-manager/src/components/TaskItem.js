// TaskItem.js - Fixed the priority badge issue
import React from "react";
import { FaTrash, FaCheck } from "react-icons/fa";

const TaskItem = ({ task, setTasks }) => {
  const toggleComplete = () => {
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, completed: !t.completed } : t)));
  };

  const deleteTask = () => {
    setTasks((prev) => prev.filter((t) => t.id !== task.id));
  };

  // Function to determine badge color based on priority
  const getBadgeColor = () => {
    switch (task.priority) {
      case "High": return "danger";
      case "Medium": return "warning";
      case "Low": return "success";
      default: return "secondary";
    }
  };

  return (
    <li className="list-group-item d-flex justify-content-between align-items-center">
      <div>
        <h5 className={task.completed ? "text-decoration-line-through" : ""}>{task.title}</h5>
        <p className="mb-1">{task.description}</p>
        <span className={`badge bg-${getBadgeColor()}`}>{task.priority}</span>
        {task.completed && <span className="badge bg-info ms-2">Completed</span>}
      </div>
      <div>
        <button 
          className={`btn ${task.completed ? "btn-secondary" : "btn-success"} me-2`} 
          onClick={toggleComplete}
        >
          <FaCheck />
        </button>
        <button className="btn btn-danger" onClick={deleteTask}>
          <FaTrash />
        </button>
      </div>
    </li>
  );
};

export default TaskItem;